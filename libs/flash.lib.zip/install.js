export default function install(anura) {
  anura.files.set("anura.flash.handler", "swf");
}
