export default function install(anura) {
  anura.files.set({ id: "anura.flash.handler" }, "swf");
}
