export default async function install(anura) {
  (
    await import(
      import.meta.url.substring(0, import.meta.url.lastIndexOf("/")) +
        "/versions/v0_0_13-install.js"
    )
  ).default(anura);
}
