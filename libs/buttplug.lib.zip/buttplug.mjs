var rt = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Dt(r) {
  return r && r.__esModule && Object.prototype.hasOwnProperty.call(r, "default") ? r.default : r;
}
var at = { exports: {} };
(function(r) {
  var e = Object.prototype.hasOwnProperty, t = "~";
  function n() {
  }
  Object.create && (n.prototype = /* @__PURE__ */ Object.create(null), new n().__proto__ || (t = !1));
  function i(l, v, p) {
    this.fn = l, this.context = v, this.once = p || !1;
  }
  function u(l, v, p, m, h) {
    if (typeof p != "function")
      throw new TypeError("The listener must be a function");
    var R = new i(p, m || l, h), E = t ? t + v : v;
    return l._events[E] ? l._events[E].fn ? l._events[E] = [l._events[E], R] : l._events[E].push(R) : (l._events[E] = R, l._eventsCount++), l;
  }
  function a(l, v) {
    --l._eventsCount === 0 ? l._events = new n() : delete l._events[v];
  }
  function f() {
    this._events = new n(), this._eventsCount = 0;
  }
  f.prototype.eventNames = function() {
    var v = [], p, m;
    if (this._eventsCount === 0)
      return v;
    for (m in p = this._events)
      e.call(p, m) && v.push(t ? m.slice(1) : m);
    return Object.getOwnPropertySymbols ? v.concat(Object.getOwnPropertySymbols(p)) : v;
  }, f.prototype.listeners = function(v) {
    var p = t ? t + v : v, m = this._events[p];
    if (!m)
      return [];
    if (m.fn)
      return [m.fn];
    for (var h = 0, R = m.length, E = new Array(R); h < R; h++)
      E[h] = m[h].fn;
    return E;
  }, f.prototype.listenerCount = function(v) {
    var p = t ? t + v : v, m = this._events[p];
    return m ? m.fn ? 1 : m.length : 0;
  }, f.prototype.emit = function(v, p, m, h, R, E) {
    var $ = t ? t + v : v;
    if (!this._events[$])
      return !1;
    var g = this._events[$], I = arguments.length, O, S;
    if (g.fn) {
      switch (g.once && this.removeListener(v, g.fn, void 0, !0), I) {
        case 1:
          return g.fn.call(g.context), !0;
        case 2:
          return g.fn.call(g.context, p), !0;
        case 3:
          return g.fn.call(g.context, p, m), !0;
        case 4:
          return g.fn.call(g.context, p, m, h), !0;
        case 5:
          return g.fn.call(g.context, p, m, h, R), !0;
        case 6:
          return g.fn.call(g.context, p, m, h, R, E), !0;
      }
      for (S = 1, O = new Array(I - 1); S < I; S++)
        O[S - 1] = arguments[S];
      g.fn.apply(g.context, O);
    } else {
      var W = g.length, C;
      for (S = 0; S < W; S++)
        switch (g[S].once && this.removeListener(v, g[S].fn, void 0, !0), I) {
          case 1:
            g[S].fn.call(g[S].context);
            break;
          case 2:
            g[S].fn.call(g[S].context, p);
            break;
          case 3:
            g[S].fn.call(g[S].context, p, m);
            break;
          case 4:
            g[S].fn.call(g[S].context, p, m, h);
            break;
          default:
            if (!O)
              for (C = 1, O = new Array(I - 1); C < I; C++)
                O[C - 1] = arguments[C];
            g[S].fn.apply(g[S].context, O);
        }
    }
    return !0;
  }, f.prototype.on = function(v, p, m) {
    return u(this, v, p, m, !1);
  }, f.prototype.once = function(v, p, m) {
    return u(this, v, p, m, !0);
  }, f.prototype.removeListener = function(v, p, m, h) {
    var R = t ? t + v : v;
    if (!this._events[R])
      return this;
    if (!p)
      return a(this, R), this;
    var E = this._events[R];
    if (E.fn)
      E.fn === p && (!h || E.once) && (!m || E.context === m) && a(this, R);
    else {
      for (var $ = 0, g = [], I = E.length; $ < I; $++)
        (E[$].fn !== p || h && !E[$].once || m && E[$].context !== m) && g.push(E[$]);
      g.length ? this._events[R] = g.length === 1 ? g[0] : g : a(this, R);
    }
    return this;
  }, f.prototype.removeAllListeners = function(v) {
    var p;
    return v ? (p = t ? t + v : v, this._events[p] && a(this, p)) : (this._events = new n(), this._eventsCount = 0), this;
  }, f.prototype.off = f.prototype.removeListener, f.prototype.addListener = f.prototype.on, f.prefixed = t, f.EventEmitter = f, r.exports = f;
})(at);
var Nt = at.exports;
const ve = /* @__PURE__ */ Dt(Nt);
/*!
 * Buttplug JS Source Code File - Visit https://buttplug.io for more info about
 * the project. Licensed under the BSD 3-Clause license. See LICENSE file in the
 * project root for full license information.
 *
 * @copyright Copyright (c) Nonpolynomial Labs LLC. All rights reserved.
 */
var ct = /* @__PURE__ */ ((r) => (r[r.Off = 0] = "Off", r[r.Error = 1] = "Error", r[r.Warn = 2] = "Warn", r[r.Info = 3] = "Info", r[r.Debug = 4] = "Debug", r[r.Trace = 5] = "Trace", r))(ct || {});
class Tt {
  /**
   * @param logMessage Log message.
   * @param logLevel: Log severity level.
   */
  constructor(e, t) {
    const n = /* @__PURE__ */ new Date(), i = n.getHours(), u = n.getMinutes(), a = n.getSeconds();
    this.timestamp = `${i}:${u}:${a}`, this.logMessage = e, this.logLevel = t;
  }
  /**
   * Returns the log message.
   */
  get Message() {
    return this.logMessage;
  }
  /**
   * Returns the log message level.
   */
  get LogLevel() {
    return this.logLevel;
  }
  /**
   * Returns the log message timestamp.
   */
  get Timestamp() {
    return this.timestamp;
  }
  /**
   * Returns a formatted string with timestamp, level, and message.
   */
  get FormattedMessage() {
    return `${ct[this.logLevel]} : ${this.timestamp} : ${this.logMessage}`;
  }
}
const ut = class le extends ve {
  /**
   * Constructor. Can only be called internally since we regulate ButtplugLogger
   * ownership.
   */
  constructor() {
    super(), this.maximumConsoleLogLevel = 0, this.maximumEventLogLevel = 0;
  }
  /**
   * Returns the stored static instance of the logger, creating one if it
   * doesn't currently exist.
   */
  static get Logger() {
    return le.sLogger === void 0 && (le.sLogger = new le()), this.sLogger;
  }
  /**
   * Set the maximum log level to output to console.
   */
  get MaximumConsoleLogLevel() {
    return this.maximumConsoleLogLevel;
  }
  /**
   * Get the maximum log level to output to console.
   */
  set MaximumConsoleLogLevel(e) {
    this.maximumConsoleLogLevel = e;
  }
  /**
   * Set the global maximum log level
   */
  get MaximumEventLogLevel() {
    return this.maximumEventLogLevel;
  }
  /**
   * Get the global maximum log level
   */
  set MaximumEventLogLevel(e) {
    this.maximumEventLogLevel = e;
  }
  /**
   * Log new message at Error level.
   */
  Error(e) {
    this.AddLogMessage(
      e,
      1
      /* Error */
    );
  }
  /**
   * Log new message at Warn level.
   */
  Warn(e) {
    this.AddLogMessage(
      e,
      2
      /* Warn */
    );
  }
  /**
   * Log new message at Info level.
   */
  Info(e) {
    this.AddLogMessage(
      e,
      3
      /* Info */
    );
  }
  /**
   * Log new message at Debug level.
   */
  Debug(e) {
    this.AddLogMessage(
      e,
      4
      /* Debug */
    );
  }
  /**
   * Log new message at Trace level.
   */
  Trace(e) {
    this.AddLogMessage(
      e,
      5
      /* Trace */
    );
  }
  /**
   * Checks to see if message should be logged, and if so, adds message to the
   * log buffer. May also print message and emit event.
   */
  AddLogMessage(e, t) {
    if (t > this.maximumEventLogLevel && t > this.maximumConsoleLogLevel)
      return;
    const n = new Tt(e, t);
    t <= this.maximumConsoleLogLevel && console.log(n.FormattedMessage), t <= this.maximumEventLogLevel && this.emit("log", n);
  }
};
ut.sLogger = void 0;
let Pt = ut;
var b;
(function(r) {
  r[r.PLAIN_TO_CLASS = 0] = "PLAIN_TO_CLASS", r[r.CLASS_TO_PLAIN = 1] = "CLASS_TO_PLAIN", r[r.CLASS_TO_CLASS = 2] = "CLASS_TO_CLASS";
})(b || (b = {}));
var kt = (
  /** @class */
  function() {
    function r() {
      this._typeMetadatas = /* @__PURE__ */ new Map(), this._transformMetadatas = /* @__PURE__ */ new Map(), this._exposeMetadatas = /* @__PURE__ */ new Map(), this._excludeMetadatas = /* @__PURE__ */ new Map(), this._ancestorsMap = /* @__PURE__ */ new Map();
    }
    return r.prototype.addTypeMetadata = function(e) {
      this._typeMetadatas.has(e.target) || this._typeMetadatas.set(e.target, /* @__PURE__ */ new Map()), this._typeMetadatas.get(e.target).set(e.propertyName, e);
    }, r.prototype.addTransformMetadata = function(e) {
      this._transformMetadatas.has(e.target) || this._transformMetadatas.set(e.target, /* @__PURE__ */ new Map()), this._transformMetadatas.get(e.target).has(e.propertyName) || this._transformMetadatas.get(e.target).set(e.propertyName, []), this._transformMetadatas.get(e.target).get(e.propertyName).push(e);
    }, r.prototype.addExposeMetadata = function(e) {
      this._exposeMetadatas.has(e.target) || this._exposeMetadatas.set(e.target, /* @__PURE__ */ new Map()), this._exposeMetadatas.get(e.target).set(e.propertyName, e);
    }, r.prototype.addExcludeMetadata = function(e) {
      this._excludeMetadatas.has(e.target) || this._excludeMetadatas.set(e.target, /* @__PURE__ */ new Map()), this._excludeMetadatas.get(e.target).set(e.propertyName, e);
    }, r.prototype.findTransformMetadatas = function(e, t, n) {
      return this.findMetadatas(this._transformMetadatas, e, t).filter(function(i) {
        return !i.options || i.options.toClassOnly === !0 && i.options.toPlainOnly === !0 ? !0 : i.options.toClassOnly === !0 ? n === b.CLASS_TO_CLASS || n === b.PLAIN_TO_CLASS : i.options.toPlainOnly === !0 ? n === b.CLASS_TO_PLAIN : !0;
      });
    }, r.prototype.findExcludeMetadata = function(e, t) {
      return this.findMetadata(this._excludeMetadatas, e, t);
    }, r.prototype.findExposeMetadata = function(e, t) {
      return this.findMetadata(this._exposeMetadatas, e, t);
    }, r.prototype.findExposeMetadataByCustomName = function(e, t) {
      return this.getExposedMetadatas(e).find(function(n) {
        return n.options && n.options.name === t;
      });
    }, r.prototype.findTypeMetadata = function(e, t) {
      return this.findMetadata(this._typeMetadatas, e, t);
    }, r.prototype.getStrategy = function(e) {
      var t = this._excludeMetadatas.get(e), n = t && t.get(void 0), i = this._exposeMetadatas.get(e), u = i && i.get(void 0);
      return n && u || !n && !u ? "none" : n ? "excludeAll" : "exposeAll";
    }, r.prototype.getExposedMetadatas = function(e) {
      return this.getMetadata(this._exposeMetadatas, e);
    }, r.prototype.getExcludedMetadatas = function(e) {
      return this.getMetadata(this._excludeMetadatas, e);
    }, r.prototype.getExposedProperties = function(e, t) {
      return this.getExposedMetadatas(e).filter(function(n) {
        return !n.options || n.options.toClassOnly === !0 && n.options.toPlainOnly === !0 ? !0 : n.options.toClassOnly === !0 ? t === b.CLASS_TO_CLASS || t === b.PLAIN_TO_CLASS : n.options.toPlainOnly === !0 ? t === b.CLASS_TO_PLAIN : !0;
      }).map(function(n) {
        return n.propertyName;
      });
    }, r.prototype.getExcludedProperties = function(e, t) {
      return this.getExcludedMetadatas(e).filter(function(n) {
        return !n.options || n.options.toClassOnly === !0 && n.options.toPlainOnly === !0 ? !0 : n.options.toClassOnly === !0 ? t === b.CLASS_TO_CLASS || t === b.PLAIN_TO_CLASS : n.options.toPlainOnly === !0 ? t === b.CLASS_TO_PLAIN : !0;
      }).map(function(n) {
        return n.propertyName;
      });
    }, r.prototype.clear = function() {
      this._typeMetadatas.clear(), this._exposeMetadatas.clear(), this._excludeMetadatas.clear(), this._ancestorsMap.clear();
    }, r.prototype.getMetadata = function(e, t) {
      var n = e.get(t), i;
      n && (i = Array.from(n.values()).filter(function(m) {
        return m.propertyName !== void 0;
      }));
      for (var u = [], a = 0, f = this.getAncestors(t); a < f.length; a++) {
        var l = f[a], v = e.get(l);
        if (v) {
          var p = Array.from(v.values()).filter(function(m) {
            return m.propertyName !== void 0;
          });
          u.push.apply(u, p);
        }
      }
      return u.concat(i || []);
    }, r.prototype.findMetadata = function(e, t, n) {
      var i = e.get(t);
      if (i) {
        var u = i.get(n);
        if (u)
          return u;
      }
      for (var a = 0, f = this.getAncestors(t); a < f.length; a++) {
        var l = f[a], v = e.get(l);
        if (v) {
          var p = v.get(n);
          if (p)
            return p;
        }
      }
    }, r.prototype.findMetadatas = function(e, t, n) {
      var i = e.get(t), u;
      i && (u = i.get(n));
      for (var a = [], f = 0, l = this.getAncestors(t); f < l.length; f++) {
        var v = l[f], p = e.get(v);
        p && p.has(n) && a.push.apply(a, p.get(n));
      }
      return a.slice().reverse().concat((u || []).slice().reverse());
    }, r.prototype.getAncestors = function(e) {
      if (!e)
        return [];
      if (!this._ancestorsMap.has(e)) {
        for (var t = [], n = Object.getPrototypeOf(e.prototype.constructor); typeof n.prototype < "u"; n = Object.getPrototypeOf(n.prototype.constructor))
          t.push(n);
        this._ancestorsMap.set(e, t);
      }
      return this._ancestorsMap.get(e);
    }, r;
  }()
), F = new kt();
function jt() {
  if (typeof globalThis < "u")
    return globalThis;
  if (typeof global < "u")
    return global;
  if (typeof window < "u")
    return window;
  if (typeof self < "u")
    return self;
}
function Bt(r) {
  return r !== null && typeof r == "object" && typeof r.then == "function";
}
var st = globalThis && globalThis.__spreadArray || function(r, e, t) {
  if (t || arguments.length === 2)
    for (var n = 0, i = e.length, u; n < i; n++)
      (u || !(n in e)) && (u || (u = Array.prototype.slice.call(e, 0, n)), u[n] = e[n]);
  return r.concat(u || Array.prototype.slice.call(e));
};
function $t(r) {
  var e = new r();
  return !(e instanceof Set) && !("push" in e) ? [] : e;
}
var oe = (
  /** @class */
  function() {
    function r(e, t) {
      this.transformationType = e, this.options = t, this.recursionStack = /* @__PURE__ */ new Set();
    }
    return r.prototype.transform = function(e, t, n, i, u, a) {
      var f = this;
      if (a === void 0 && (a = 0), Array.isArray(t) || t instanceof Set) {
        var l = i && this.transformationType === b.PLAIN_TO_CLASS ? $t(i) : [];
        return t.forEach(function(g, I) {
          var O = e ? e[I] : void 0;
          if (!f.options.enableCircularCheck || !f.isCircular(g)) {
            var S = void 0;
            if (typeof n != "function" && n && n.options && n.options.discriminator && n.options.discriminator.property && n.options.discriminator.subTypes) {
              if (f.transformationType === b.PLAIN_TO_CLASS) {
                S = n.options.discriminator.subTypes.find(function(Y) {
                  return Y.name === g[n.options.discriminator.property];
                });
                var W = { newObject: l, object: g, property: void 0 }, C = n.typeFunction(W);
                S === void 0 ? S = C : S = S.value, n.options.keepDiscriminatorProperty || delete g[n.options.discriminator.property];
              }
              f.transformationType === b.CLASS_TO_CLASS && (S = g.constructor), f.transformationType === b.CLASS_TO_PLAIN && (g[n.options.discriminator.property] = n.options.discriminator.subTypes.find(function(Y) {
                return Y.value === g.constructor;
              }).name);
            } else
              S = n;
            var k = f.transform(O, g, S, void 0, g instanceof Map, a + 1);
            l instanceof Set ? l.add(k) : l.push(k);
          } else
            f.transformationType === b.CLASS_TO_CLASS && (l instanceof Set ? l.add(g) : l.push(g));
        }), l;
      } else {
        if (n === String && !u)
          return t == null ? t : String(t);
        if (n === Number && !u)
          return t == null ? t : Number(t);
        if (n === Boolean && !u)
          return t == null ? t : !!t;
        if ((n === Date || t instanceof Date) && !u)
          return t instanceof Date ? new Date(t.valueOf()) : t == null ? t : new Date(t);
        if (jt().Buffer && (n === Buffer || t instanceof Buffer) && !u)
          return t == null ? t : Buffer.from(t);
        if (Bt(t) && !u)
          return new Promise(function(g, I) {
            t.then(function(O) {
              return g(f.transform(void 0, O, n, void 0, void 0, a + 1));
            }, I);
          });
        if (!u && t !== null && typeof t == "object" && typeof t.then == "function")
          return t;
        if (typeof t == "object" && t !== null) {
          !n && t.constructor !== Object && (!Array.isArray(t) && t.constructor === Array || (n = t.constructor)), !n && e && (n = e.constructor), this.options.enableCircularCheck && this.recursionStack.add(t);
          var v = this.getKeys(n, t, u), p = e || {};
          !e && (this.transformationType === b.PLAIN_TO_CLASS || this.transformationType === b.CLASS_TO_CLASS) && (u ? p = /* @__PURE__ */ new Map() : n ? p = new n() : p = {});
          for (var m = function(g) {
            if (g === "__proto__" || g === "constructor")
              return "continue";
            var I = g, O = g, S = g;
            if (!h.options.ignoreDecorators && n) {
              if (h.transformationType === b.PLAIN_TO_CLASS) {
                var W = F.findExposeMetadataByCustomName(n, g);
                W && (S = W.propertyName, O = W.propertyName);
              } else if (h.transformationType === b.CLASS_TO_PLAIN || h.transformationType === b.CLASS_TO_CLASS) {
                var W = F.findExposeMetadata(n, g);
                W && W.options && W.options.name && (O = W.options.name);
              }
            }
            var C = void 0;
            h.transformationType === b.PLAIN_TO_CLASS ? C = t[I] : t instanceof Map ? C = t.get(I) : t[I] instanceof Function ? C = t[I]() : C = t[I];
            var k = void 0, Y = C instanceof Map;
            if (n && u)
              k = n;
            else if (n) {
              var N = F.findTypeMetadata(n, S);
              if (N) {
                var Me = { newObject: p, object: t, property: S }, he = N.typeFunction ? N.typeFunction(Me) : N.reflectedType;
                N.options && N.options.discriminator && N.options.discriminator.property && N.options.discriminator.subTypes ? t[I] instanceof Array ? k = N : (h.transformationType === b.PLAIN_TO_CLASS && (k = N.options.discriminator.subTypes.find(function(q) {
                  if (C && C instanceof Object && N.options.discriminator.property in C)
                    return q.name === C[N.options.discriminator.property];
                }), k === void 0 ? k = he : k = k.value, N.options.keepDiscriminatorProperty || C && C instanceof Object && N.options.discriminator.property in C && delete C[N.options.discriminator.property]), h.transformationType === b.CLASS_TO_CLASS && (k = C.constructor), h.transformationType === b.CLASS_TO_PLAIN && C && (C[N.options.discriminator.property] = N.options.discriminator.subTypes.find(function(q) {
                  return q.value === C.constructor;
                }).name)) : k = he, Y = Y || N.reflectedType === Map;
              } else if (h.options.targetMaps)
                h.options.targetMaps.filter(function(q) {
                  return q.target === n && !!q.properties[S];
                }).forEach(function(q) {
                  return k = q.properties[S];
                });
              else if (h.options.enableImplicitConversion && h.transformationType === b.PLAIN_TO_CLASS) {
                var pe = Reflect.getMetadata("design:type", n.prototype, S);
                pe && (k = pe);
              }
            }
            var K = Array.isArray(t[I]) ? h.getReflectedType(n, S) : void 0, fe = e ? e[I] : void 0;
            if (p.constructor.prototype) {
              var re = Object.getOwnPropertyDescriptor(p.constructor.prototype, O);
              if ((h.transformationType === b.PLAIN_TO_CLASS || h.transformationType === b.CLASS_TO_CLASS) && // eslint-disable-next-line @typescript-eslint/unbound-method
              (re && !re.set || p[O] instanceof Function))
                return "continue";
            }
            if (!h.options.enableCircularCheck || !h.isCircular(C)) {
              var te = h.transformationType === b.PLAIN_TO_CLASS ? O : g, L = void 0;
              h.transformationType === b.CLASS_TO_PLAIN ? (L = t[te], L = h.applyCustomTransformations(L, n, te, t, h.transformationType), L = t[te] === L ? C : L, L = h.transform(fe, L, k, K, Y, a + 1)) : C === void 0 && h.options.exposeDefaultValues ? L = p[O] : (L = h.transform(fe, C, k, K, Y, a + 1), L = h.applyCustomTransformations(L, n, te, t, h.transformationType)), (L !== void 0 || h.options.exposeUnsetFields) && (p instanceof Map ? p.set(O, L) : p[O] = L);
            } else if (h.transformationType === b.CLASS_TO_CLASS) {
              var L = C;
              L = h.applyCustomTransformations(L, n, g, t, h.transformationType), (L !== void 0 || h.options.exposeUnsetFields) && (p instanceof Map ? p.set(O, L) : p[O] = L);
            }
          }, h = this, R = 0, E = v; R < E.length; R++) {
            var $ = E[R];
            m($);
          }
          return this.options.enableCircularCheck && this.recursionStack.delete(t), p;
        } else
          return t;
      }
    }, r.prototype.applyCustomTransformations = function(e, t, n, i, u) {
      var a = this, f = F.findTransformMetadatas(t, n, this.transformationType);
      return this.options.version !== void 0 && (f = f.filter(function(l) {
        return l.options ? a.checkVersion(l.options.since, l.options.until) : !0;
      })), this.options.groups && this.options.groups.length ? f = f.filter(function(l) {
        return l.options ? a.checkGroups(l.options.groups) : !0;
      }) : f = f.filter(function(l) {
        return !l.options || !l.options.groups || !l.options.groups.length;
      }), f.forEach(function(l) {
        e = l.transformFn({ value: e, key: n, obj: i, type: u, options: a.options });
      }), e;
    }, r.prototype.isCircular = function(e) {
      return this.recursionStack.has(e);
    }, r.prototype.getReflectedType = function(e, t) {
      if (e) {
        var n = F.findTypeMetadata(e, t);
        return n ? n.reflectedType : void 0;
      }
    }, r.prototype.getKeys = function(e, t, n) {
      var i = this, u = F.getStrategy(e);
      u === "none" && (u = this.options.strategy || "exposeAll");
      var a = [];
      if ((u === "exposeAll" || n) && (t instanceof Map ? a = Array.from(t.keys()) : a = Object.keys(t)), n)
        return a;
      if (this.options.ignoreDecorators && this.options.excludeExtraneousValues && e) {
        var f = F.getExposedProperties(e, this.transformationType), l = F.getExcludedProperties(e, this.transformationType);
        a = st(st([], f, !0), l, !0);
      }
      if (!this.options.ignoreDecorators && e) {
        var f = F.getExposedProperties(e, this.transformationType);
        this.transformationType === b.PLAIN_TO_CLASS && (f = f.map(function(m) {
          var h = F.findExposeMetadata(e, m);
          return h && h.options && h.options.name ? h.options.name : m;
        })), this.options.excludeExtraneousValues ? a = f : a = a.concat(f);
        var v = F.getExcludedProperties(e, this.transformationType);
        v.length > 0 && (a = a.filter(function(m) {
          return !v.includes(m);
        })), this.options.version !== void 0 && (a = a.filter(function(m) {
          var h = F.findExposeMetadata(e, m);
          return !h || !h.options ? !0 : i.checkVersion(h.options.since, h.options.until);
        })), this.options.groups && this.options.groups.length ? a = a.filter(function(m) {
          var h = F.findExposeMetadata(e, m);
          return !h || !h.options ? !0 : i.checkGroups(h.options.groups);
        }) : a = a.filter(function(m) {
          var h = F.findExposeMetadata(e, m);
          return !h || !h.options || !h.options.groups || !h.options.groups.length;
        });
      }
      return this.options.excludePrefixes && this.options.excludePrefixes.length && (a = a.filter(function(p) {
        return i.options.excludePrefixes.every(function(m) {
          return p.substr(0, m.length) !== m;
        });
      })), a = a.filter(function(p, m, h) {
        return h.indexOf(p) === m;
      }), a;
    }, r.prototype.checkVersion = function(e, t) {
      var n = !0;
      return n && e && (n = this.options.version >= e), n && t && (n = this.options.version < t), n;
    }, r.prototype.checkGroups = function(e) {
      return e ? this.options.groups.some(function(t) {
        return e.includes(t);
      }) : !0;
    }, r;
  }()
), ae = {
  enableCircularCheck: !1,
  enableImplicitConversion: !1,
  excludeExtraneousValues: !1,
  excludePrefixes: void 0,
  exposeDefaultValues: !1,
  exposeUnsetFields: !0,
  groups: void 0,
  ignoreDecorators: !1,
  strategy: void 0,
  targetMaps: void 0,
  version: void 0
}, G = globalThis && globalThis.__assign || function() {
  return G = Object.assign || function(r) {
    for (var e, t = 1, n = arguments.length; t < n; t++) {
      e = arguments[t];
      for (var i in e)
        Object.prototype.hasOwnProperty.call(e, i) && (r[i] = e[i]);
    }
    return r;
  }, G.apply(this, arguments);
}, Ft = (
  /** @class */
  function() {
    function r() {
    }
    return r.prototype.instanceToPlain = function(e, t) {
      var n = new oe(b.CLASS_TO_PLAIN, G(G({}, ae), t));
      return n.transform(void 0, e, void 0, void 0, void 0, void 0);
    }, r.prototype.classToPlainFromExist = function(e, t, n) {
      var i = new oe(b.CLASS_TO_PLAIN, G(G({}, ae), n));
      return i.transform(t, e, void 0, void 0, void 0, void 0);
    }, r.prototype.plainToInstance = function(e, t, n) {
      var i = new oe(b.PLAIN_TO_CLASS, G(G({}, ae), n));
      return i.transform(void 0, t, e, void 0, void 0, void 0);
    }, r.prototype.plainToClassFromExist = function(e, t, n) {
      var i = new oe(b.PLAIN_TO_CLASS, G(G({}, ae), n));
      return i.transform(e, t, void 0, void 0, void 0, void 0);
    }, r.prototype.instanceToInstance = function(e, t) {
      var n = new oe(b.CLASS_TO_CLASS, G(G({}, ae), t));
      return n.transform(void 0, e, void 0, void 0, void 0, void 0);
    }, r.prototype.classToClassFromExist = function(e, t, n) {
      var i = new oe(b.CLASS_TO_CLASS, G(G({}, ae), n));
      return i.transform(t, e, void 0, void 0, void 0, void 0);
    }, r.prototype.serialize = function(e, t) {
      return JSON.stringify(this.instanceToPlain(e, t));
    }, r.prototype.deserialize = function(e, t, n) {
      var i = JSON.parse(t);
      return this.plainToInstance(e, i, n);
    }, r.prototype.deserializeArray = function(e, t, n) {
      var i = JSON.parse(t);
      return this.plainToInstance(e, i, n);
    }, r;
  }()
);
function Le(r, e) {
  return e === void 0 && (e = {}), function(t, n) {
    var i = Reflect.getMetadata("design:type", t, n);
    F.addTypeMetadata({
      target: t.constructor,
      propertyName: n,
      reflectedType: i,
      typeFunction: r,
      options: e
    });
  };
}
var ft = new Ft();
function Ut(r, e) {
  return ft.instanceToPlain(r, e);
}
function Wt(r, e, t) {
  return ft.plainToInstance(r, e, t);
}
/*! *****************************************************************************
Copyright (C) Microsoft. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
var it;
(function(r) {
  (function(e) {
    var t = typeof rt == "object" ? rt : typeof self == "object" ? self : typeof this == "object" ? this : Function("return this;")(), n = i(r);
    typeof t.Reflect > "u" ? t.Reflect = r : n = i(t.Reflect, n), e(n);
    function i(u, a) {
      return function(f, l) {
        typeof u[f] != "function" && Object.defineProperty(u, f, { configurable: !0, writable: !0, value: l }), a && a(f, l);
      };
    }
  })(function(e) {
    var t = Object.prototype.hasOwnProperty, n = typeof Symbol == "function", i = n && typeof Symbol.toPrimitive < "u" ? Symbol.toPrimitive : "@@toPrimitive", u = n && typeof Symbol.iterator < "u" ? Symbol.iterator : "@@iterator", a = typeof Object.create == "function", f = { __proto__: [] } instanceof Array, l = !a && !f, v = {
      // create an object in dictionary mode (a.k.a. "slow" mode in v8)
      create: a ? function() {
        return Ce(/* @__PURE__ */ Object.create(null));
      } : f ? function() {
        return Ce({ __proto__: null });
      } : function() {
        return Ce({});
      },
      has: l ? function(s, o) {
        return t.call(s, o);
      } : function(s, o) {
        return o in s;
      },
      get: l ? function(s, o) {
        return t.call(s, o) ? s[o] : void 0;
      } : function(s, o) {
        return s[o];
      }
    }, p = Object.getPrototypeOf(Function), m = typeof process == "object" && process.env && process.env.REFLECT_METADATA_USE_MAP_POLYFILL === "true", h = !m && typeof Map == "function" && typeof Map.prototype.entries == "function" ? Map : Lt(), R = !m && typeof Set == "function" && typeof Set.prototype.entries == "function" ? Set : It(), E = !m && typeof WeakMap == "function" ? WeakMap : Rt(), $ = new E();
    function g(s, o, c, d) {
      if (T(c)) {
        if (!Ve(s))
          throw new TypeError();
        if (!et(o))
          throw new TypeError();
        return he(s, o);
      } else {
        if (!Ve(s))
          throw new TypeError();
        if (!j(o))
          throw new TypeError();
        if (!j(d) && !T(d) && !se(d))
          throw new TypeError();
        return se(d) && (d = void 0), c = Z(c), pe(s, o, c, d);
      }
    }
    e("decorate", g);
    function I(s, o) {
      function c(d, y) {
        if (!j(d))
          throw new TypeError();
        if (!T(y) && !Ct(y))
          throw new TypeError();
        q(s, o, d, y);
      }
      return c;
    }
    e("metadata", I);
    function O(s, o, c, d) {
      if (!j(c))
        throw new TypeError();
      return T(d) || (d = Z(d)), q(s, o, c, d);
    }
    e("defineMetadata", O);
    function S(s, o, c) {
      if (!j(o))
        throw new TypeError();
      return T(c) || (c = Z(c)), fe(s, o, c);
    }
    e("hasMetadata", S);
    function W(s, o, c) {
      if (!j(o))
        throw new TypeError();
      return T(c) || (c = Z(c)), re(s, o, c);
    }
    e("hasOwnMetadata", W);
    function C(s, o, c) {
      if (!j(o))
        throw new TypeError();
      return T(c) || (c = Z(c)), te(s, o, c);
    }
    e("getMetadata", C);
    function k(s, o, c) {
      if (!j(o))
        throw new TypeError();
      return T(c) || (c = Z(c)), L(s, o, c);
    }
    e("getOwnMetadata", k);
    function Y(s, o) {
      if (!j(s))
        throw new TypeError();
      return T(o) || (o = Z(o)), Ze(s, o);
    }
    e("getMetadataKeys", Y);
    function N(s, o) {
      if (!j(s))
        throw new TypeError();
      return T(o) || (o = Z(o)), Qe(s, o);
    }
    e("getOwnMetadataKeys", N);
    function Me(s, o, c) {
      if (!j(o))
        throw new TypeError();
      T(c) || (c = Z(c));
      var d = K(
        o,
        c,
        /*Create*/
        !1
      );
      if (T(d) || !d.delete(s))
        return !1;
      if (d.size > 0)
        return !0;
      var y = $.get(o);
      return y.delete(c), y.size > 0 || $.delete(o), !0;
    }
    e("deleteMetadata", Me);
    function he(s, o) {
      for (var c = s.length - 1; c >= 0; --c) {
        var d = s[c], y = d(o);
        if (!T(y) && !se(y)) {
          if (!et(y))
            throw new TypeError();
          o = y;
        }
      }
      return o;
    }
    function pe(s, o, c, d) {
      for (var y = s.length - 1; y >= 0; --y) {
        var B = s[y], _ = B(o, c, d);
        if (!T(_) && !se(_)) {
          if (!j(_))
            throw new TypeError();
          d = _;
        }
      }
      return d;
    }
    function K(s, o, c) {
      var d = $.get(s);
      if (T(d)) {
        if (!c)
          return;
        d = new h(), $.set(s, d);
      }
      var y = d.get(o);
      if (T(y)) {
        if (!c)
          return;
        y = new h(), d.set(o, y);
      }
      return y;
    }
    function fe(s, o, c) {
      var d = re(s, o, c);
      if (d)
        return !0;
      var y = be(o);
      return se(y) ? !1 : fe(s, y, c);
    }
    function re(s, o, c) {
      var d = K(
        o,
        c,
        /*Create*/
        !1
      );
      return T(d) ? !1 : Mt(d.has(s));
    }
    function te(s, o, c) {
      var d = re(s, o, c);
      if (d)
        return L(s, o, c);
      var y = be(o);
      if (!se(y))
        return te(s, y, c);
    }
    function L(s, o, c) {
      var d = K(
        o,
        c,
        /*Create*/
        !1
      );
      if (!T(d))
        return d.get(s);
    }
    function q(s, o, c, d) {
      var y = K(
        c,
        d,
        /*Create*/
        !0
      );
      y.set(s, o);
    }
    function Ze(s, o) {
      var c = Qe(s, o), d = be(s);
      if (d === null)
        return c;
      var y = Ze(d, o);
      if (y.length <= 0)
        return c;
      if (c.length <= 0)
        return y;
      for (var B = new R(), _ = [], M = 0, w = c; M < w.length; M++) {
        var x = w[M], A = B.has(x);
        A || (B.add(x), _.push(x));
      }
      for (var V = 0, nt = y; V < nt.length; V++) {
        var x = nt[V], A = B.has(x);
        A || (B.add(x), _.push(x));
      }
      return _;
    }
    function Qe(s, o) {
      var c = [], d = K(
        s,
        o,
        /*Create*/
        !1
      );
      if (T(d))
        return c;
      for (var y = d.keys(), B = xt(y), _ = 0; ; ) {
        var M = Et(B);
        if (!M)
          return c.length = _, c;
        var w = At(M);
        try {
          c[_] = w;
        } catch (x) {
          try {
            Ot(B);
          } finally {
            throw x;
          }
        }
        _++;
      }
    }
    function Ke(s) {
      if (s === null)
        return 1;
      switch (typeof s) {
        case "undefined":
          return 0;
        case "boolean":
          return 2;
        case "string":
          return 3;
        case "symbol":
          return 4;
        case "number":
          return 5;
        case "object":
          return s === null ? 1 : 6;
        default:
          return 6;
      }
    }
    function T(s) {
      return s === void 0;
    }
    function se(s) {
      return s === null;
    }
    function wt(s) {
      return typeof s == "symbol";
    }
    function j(s) {
      return typeof s == "object" ? s !== null : typeof s == "function";
    }
    function _t(s, o) {
      switch (Ke(s)) {
        case 0:
          return s;
        case 1:
          return s;
        case 2:
          return s;
        case 3:
          return s;
        case 4:
          return s;
        case 5:
          return s;
      }
      var c = o === 3 ? "string" : o === 5 ? "number" : "default", d = tt(s, i);
      if (d !== void 0) {
        var y = d.call(s, c);
        if (j(y))
          throw new TypeError();
        return y;
      }
      return St(s, c === "default" ? "number" : c);
    }
    function St(s, o) {
      if (o === "string") {
        var c = s.toString;
        if (ie(c)) {
          var d = c.call(s);
          if (!j(d))
            return d;
        }
        var y = s.valueOf;
        if (ie(y)) {
          var d = y.call(s);
          if (!j(d))
            return d;
        }
      } else {
        var y = s.valueOf;
        if (ie(y)) {
          var d = y.call(s);
          if (!j(d))
            return d;
        }
        var B = s.toString;
        if (ie(B)) {
          var d = B.call(s);
          if (!j(d))
            return d;
        }
      }
      throw new TypeError();
    }
    function Mt(s) {
      return !!s;
    }
    function bt(s) {
      return "" + s;
    }
    function Z(s) {
      var o = _t(
        s,
        3
        /* String */
      );
      return wt(o) ? o : bt(o);
    }
    function Ve(s) {
      return Array.isArray ? Array.isArray(s) : s instanceof Object ? s instanceof Array : Object.prototype.toString.call(s) === "[object Array]";
    }
    function ie(s) {
      return typeof s == "function";
    }
    function et(s) {
      return typeof s == "function";
    }
    function Ct(s) {
      switch (Ke(s)) {
        case 3:
          return !0;
        case 4:
          return !0;
        default:
          return !1;
      }
    }
    function tt(s, o) {
      var c = s[o];
      if (c != null) {
        if (!ie(c))
          throw new TypeError();
        return c;
      }
    }
    function xt(s) {
      var o = tt(s, u);
      if (!ie(o))
        throw new TypeError();
      var c = o.call(s);
      if (!j(c))
        throw new TypeError();
      return c;
    }
    function At(s) {
      return s.value;
    }
    function Et(s) {
      var o = s.next();
      return o.done ? !1 : o;
    }
    function Ot(s) {
      var o = s.return;
      o && o.call(s);
    }
    function be(s) {
      var o = Object.getPrototypeOf(s);
      if (typeof s != "function" || s === p || o !== p)
        return o;
      var c = s.prototype, d = c && Object.getPrototypeOf(c);
      if (d == null || d === Object.prototype)
        return o;
      var y = d.constructor;
      return typeof y != "function" || y === s ? o : y;
    }
    function Lt() {
      var s = {}, o = [], c = (
        /** @class */
        function() {
          function _(M, w, x) {
            this._index = 0, this._keys = M, this._values = w, this._selector = x;
          }
          return _.prototype["@@iterator"] = function() {
            return this;
          }, _.prototype[u] = function() {
            return this;
          }, _.prototype.next = function() {
            var M = this._index;
            if (M >= 0 && M < this._keys.length) {
              var w = this._selector(this._keys[M], this._values[M]);
              return M + 1 >= this._keys.length ? (this._index = -1, this._keys = o, this._values = o) : this._index++, { value: w, done: !1 };
            }
            return { value: void 0, done: !0 };
          }, _.prototype.throw = function(M) {
            throw this._index >= 0 && (this._index = -1, this._keys = o, this._values = o), M;
          }, _.prototype.return = function(M) {
            return this._index >= 0 && (this._index = -1, this._keys = o, this._values = o), { value: M, done: !0 };
          }, _;
        }()
      );
      return (
        /** @class */
        function() {
          function _() {
            this._keys = [], this._values = [], this._cacheKey = s, this._cacheIndex = -2;
          }
          return Object.defineProperty(_.prototype, "size", {
            get: function() {
              return this._keys.length;
            },
            enumerable: !0,
            configurable: !0
          }), _.prototype.has = function(M) {
            return this._find(
              M,
              /*insert*/
              !1
            ) >= 0;
          }, _.prototype.get = function(M) {
            var w = this._find(
              M,
              /*insert*/
              !1
            );
            return w >= 0 ? this._values[w] : void 0;
          }, _.prototype.set = function(M, w) {
            var x = this._find(
              M,
              /*insert*/
              !0
            );
            return this._values[x] = w, this;
          }, _.prototype.delete = function(M) {
            var w = this._find(
              M,
              /*insert*/
              !1
            );
            if (w >= 0) {
              for (var x = this._keys.length, A = w + 1; A < x; A++)
                this._keys[A - 1] = this._keys[A], this._values[A - 1] = this._values[A];
              return this._keys.length--, this._values.length--, M === this._cacheKey && (this._cacheKey = s, this._cacheIndex = -2), !0;
            }
            return !1;
          }, _.prototype.clear = function() {
            this._keys.length = 0, this._values.length = 0, this._cacheKey = s, this._cacheIndex = -2;
          }, _.prototype.keys = function() {
            return new c(this._keys, this._values, d);
          }, _.prototype.values = function() {
            return new c(this._keys, this._values, y);
          }, _.prototype.entries = function() {
            return new c(this._keys, this._values, B);
          }, _.prototype["@@iterator"] = function() {
            return this.entries();
          }, _.prototype[u] = function() {
            return this.entries();
          }, _.prototype._find = function(M, w) {
            return this._cacheKey !== M && (this._cacheIndex = this._keys.indexOf(this._cacheKey = M)), this._cacheIndex < 0 && w && (this._cacheIndex = this._keys.length, this._keys.push(M), this._values.push(void 0)), this._cacheIndex;
          }, _;
        }()
      );
      function d(_, M) {
        return _;
      }
      function y(_, M) {
        return M;
      }
      function B(_, M) {
        return [_, M];
      }
    }
    function It() {
      return (
        /** @class */
        function() {
          function s() {
            this._map = new h();
          }
          return Object.defineProperty(s.prototype, "size", {
            get: function() {
              return this._map.size;
            },
            enumerable: !0,
            configurable: !0
          }), s.prototype.has = function(o) {
            return this._map.has(o);
          }, s.prototype.add = function(o) {
            return this._map.set(o, o), this;
          }, s.prototype.delete = function(o) {
            return this._map.delete(o);
          }, s.prototype.clear = function() {
            this._map.clear();
          }, s.prototype.keys = function() {
            return this._map.keys();
          }, s.prototype.values = function() {
            return this._map.values();
          }, s.prototype.entries = function() {
            return this._map.entries();
          }, s.prototype["@@iterator"] = function() {
            return this.keys();
          }, s.prototype[u] = function() {
            return this.keys();
          }, s;
        }()
      );
    }
    function Rt() {
      var s = 16, o = v.create(), c = d();
      return (
        /** @class */
        function() {
          function w() {
            this._key = d();
          }
          return w.prototype.has = function(x) {
            var A = y(
              x,
              /*create*/
              !1
            );
            return A !== void 0 ? v.has(A, this._key) : !1;
          }, w.prototype.get = function(x) {
            var A = y(
              x,
              /*create*/
              !1
            );
            return A !== void 0 ? v.get(A, this._key) : void 0;
          }, w.prototype.set = function(x, A) {
            var V = y(
              x,
              /*create*/
              !0
            );
            return V[this._key] = A, this;
          }, w.prototype.delete = function(x) {
            var A = y(
              x,
              /*create*/
              !1
            );
            return A !== void 0 ? delete A[this._key] : !1;
          }, w.prototype.clear = function() {
            this._key = d();
          }, w;
        }()
      );
      function d() {
        var w;
        do
          w = "@@WeakMap@@" + M();
        while (v.has(o, w));
        return o[w] = !0, w;
      }
      function y(w, x) {
        if (!t.call(w, c)) {
          if (!x)
            return;
          Object.defineProperty(w, c, { value: v.create() });
        }
        return w[c];
      }
      function B(w, x) {
        for (var A = 0; A < x; ++A)
          w[A] = Math.random() * 255 | 0;
        return w;
      }
      function _(w) {
        return typeof Uint8Array == "function" ? typeof crypto < "u" ? crypto.getRandomValues(new Uint8Array(w)) : typeof msCrypto < "u" ? msCrypto.getRandomValues(new Uint8Array(w)) : B(new Uint8Array(w), w) : B(new Array(w), w);
      }
      function M() {
        var w = _(s);
        w[6] = w[6] & 79 | 64, w[8] = w[8] & 191 | 128;
        for (var x = "", A = 0; A < s; ++A) {
          var V = w[A];
          (A === 4 || A === 6 || A === 8) && (x += "-"), V < 16 && (x += "0"), x += V.toString(16).toLowerCase();
        }
        return x;
      }
    }
    function Ce(s) {
      return s.__ = void 0, delete s.__, s;
    }
  });
})(it || (it = {}));
var Gt = Object.defineProperty, zt = Object.getOwnPropertyDescriptor, Ie = (r, e, t, n) => {
  for (var i = n > 1 ? void 0 : n ? zt(e, t) : e, u = r.length - 1, a; u >= 0; u--)
    (a = r[u]) && (i = (n ? a(e, t, i) : a(i)) || i);
  return n && i && Gt(e, t, i), i;
};
const X = 0, D = 1, Jt = 4294967295, ge = 3;
class Re {
  constructor(e) {
    Object.assign(this, e);
  }
  update() {
    var e, t, n, i, u;
    (e = this.ScalarCmd) == null || e.forEach((a, f) => a.Index = f), (t = this.RotateCmd) == null || t.forEach((a, f) => a.Index = f), (n = this.LinearCmd) == null || n.forEach((a, f) => a.Index = f), (i = this.SensorReadCmd) == null || i.forEach((a, f) => a.Index = f), (u = this.SensorSubscribeCmd) == null || u.forEach((a, f) => a.Index = f);
  }
}
var ce = /* @__PURE__ */ ((r) => (r.Unknown = "Unknown", r.Vibrate = "Vibrate", r.Rotate = "Rotate", r.Oscillate = "Oscillate", r.Constrict = "Constrict", r.Inflate = "Inflate", r.Position = "Position", r))(ce || {}), ee = /* @__PURE__ */ ((r) => (r.Unknown = "Unknown", r.Battery = "Battery", r.RSSI = "RSSI", r.Button = "Button", r.Pressure = "Pressure", r))(ee || {});
class qt {
  constructor(e) {
    this.Index = 0, Object.assign(this, e);
  }
}
class Ht {
  constructor(e) {
    this.Endpoints = e;
  }
}
class Yt {
  constructor(e) {
    this.Index = 0, Object.assign(this, e);
  }
}
class H {
  constructor(e) {
    this.Id = e;
  }
  // tslint:disable-next-line:ban-types
  get Type() {
    return this.constructor;
  }
  toJSON() {
    return JSON.stringify(this.toProtocolFormat());
  }
  toProtocolFormat() {
    const e = {};
    return e[this.constructor.Name] = Ut(this), e;
  }
  update() {
  }
}
class J extends H {
  constructor(e, t) {
    super(t), this.DeviceIndex = e, this.Id = t;
  }
}
class ue extends H {
  constructor(e = X) {
    super(e), this.Id = e;
  }
}
class we extends ue {
  constructor(e = D) {
    super(e), this.Id = e;
  }
}
we.Name = "Ok";
class dt extends H {
  constructor(e = D) {
    super(e), this.Id = e;
  }
}
dt.Name = "Ping";
var z = /* @__PURE__ */ ((r) => (r[r.ERROR_UNKNOWN = 0] = "ERROR_UNKNOWN", r[r.ERROR_INIT = 1] = "ERROR_INIT", r[r.ERROR_PING = 2] = "ERROR_PING", r[r.ERROR_MSG = 3] = "ERROR_MSG", r[r.ERROR_DEVICE = 4] = "ERROR_DEVICE", r))(z || {});
let Q = class extends H {
  constructor(e, t = 0, n = D) {
    super(n), this.ErrorMessage = e, this.ErrorCode = t, this.Id = n;
  }
  get Schemversion() {
    return 0;
  }
};
Q.Name = "Error";
class De {
  constructor(e) {
    Object.assign(this, e);
  }
}
Ie([
  Le(() => Re)
], De.prototype, "DeviceMessages", 2);
class Ne extends H {
  constructor(e, t = D) {
    super(t), this.Devices = e, this.Id = t;
  }
  update() {
    for (const e of this.Devices)
      e.DeviceMessages.update();
  }
}
Ne.Name = "DeviceList";
Ie([
  Le(() => De)
], Ne.prototype, "Devices", 2);
class _e extends ue {
  constructor(e) {
    super(), Object.assign(this, e);
  }
  update() {
    this.DeviceMessages.update();
  }
}
_e.Name = "DeviceAdded";
Ie([
  Le(() => Re)
], _e.prototype, "DeviceMessages", 2);
class Te extends ue {
  constructor(e) {
    super(), this.DeviceIndex = e;
  }
}
Te.Name = "DeviceRemoved";
class Pe extends H {
  constructor(e = D) {
    super(e), this.Id = e;
  }
}
Pe.Name = "RequestDeviceList";
class ke extends H {
  constructor(e = D) {
    super(e), this.Id = e;
  }
}
ke.Name = "StartScanning";
class je extends H {
  constructor(e = D) {
    super(e), this.Id = e;
  }
}
je.Name = "StopScanning";
class Be extends ue {
  constructor() {
    super();
  }
}
Be.Name = "ScanningFinished";
class $e extends H {
  constructor(e, t = 0, n = D) {
    super(n), this.ClientName = e, this.MessageVersion = t, this.Id = n;
  }
}
$e.Name = "RequestServerInfo";
class Fe extends ue {
  constructor(e, t, n, i = D) {
    super(), this.MessageVersion = e, this.MaxPingTime = t, this.ServerName = n, this.Id = i;
  }
}
Fe.Name = "ServerInfo";
class Ue extends J {
  constructor(e = -1, t = D) {
    super(e, t), this.DeviceIndex = e, this.Id = t;
  }
}
Ue.Name = "StopDeviceCmd";
class We extends H {
  constructor(e = D) {
    super(e), this.Id = e;
  }
}
We.Name = "StopAllDevices";
class Se {
  constructor(e) {
    this.Index = e;
  }
}
class xe extends Se {
  constructor(e, t, n) {
    super(e), this.Scalar = t, this.ActuatorType = n;
  }
}
class me extends J {
  constructor(e, t = -1, n = D) {
    super(t, n), this.Scalars = e, this.DeviceIndex = t, this.Id = n;
  }
}
me.Name = "ScalarCmd";
class ht extends Se {
  constructor(e, t, n) {
    super(e), this.Speed = t, this.Clockwise = n;
  }
}
const pt = class lt extends J {
  constructor(e, t = -1, n = D) {
    super(t, n), this.Rotations = e, this.DeviceIndex = t, this.Id = n;
  }
  static Create(e, t) {
    const n = new Array();
    let i = 0;
    for (const [u, a] of t)
      n.push(new ht(i, u, a)), ++i;
    return new lt(n, e);
  }
};
pt.Name = "RotateCmd";
let Ae = pt;
class gt extends Se {
  constructor(e, t, n) {
    super(e), this.Position = t, this.Duration = n;
  }
}
const mt = class yt extends J {
  constructor(e, t = -1, n = D) {
    super(t, n), this.Vectors = e, this.DeviceIndex = t, this.Id = n;
  }
  static Create(e, t) {
    const n = new Array();
    let i = 0;
    for (const u of t)
      n.push(new gt(i, u[0], u[1])), ++i;
    return new yt(n, e);
  }
};
mt.Name = "LinearCmd";
let Ee = mt;
class Ge extends J {
  constructor(e, t, n, i = D) {
    super(e, i), this.DeviceIndex = e, this.SensorIndex = t, this.SensorType = n, this.Id = i;
  }
}
Ge.Name = "SensorReadCmd";
class ze extends J {
  constructor(e, t, n, i, u = D) {
    super(e, u), this.DeviceIndex = e, this.SensorIndex = t, this.SensorType = n, this.Data = i, this.Id = u;
  }
}
ze.Name = "SensorReading";
class Je extends J {
  constructor(e, t, n, i, u = D) {
    super(e, u), this.DeviceIndex = e, this.Endpoint = t, this.ExpectedLength = n, this.Timeout = i, this.Id = u;
  }
}
Je.Name = "RawReadCmd";
class qe extends J {
  constructor(e, t, n, i, u = D) {
    super(e, u), this.DeviceIndex = e, this.Endpoint = t, this.Data = n, this.WriteWithResponse = i, this.Id = u;
  }
}
qe.Name = "RawWriteCmd";
class He extends J {
  constructor(e, t, n = D) {
    super(e, n), this.DeviceIndex = e, this.Endpoint = t, this.Id = n;
  }
}
He.Name = "RawSubscribeCmd";
class Ye extends J {
  constructor(e, t, n = D) {
    super(e, n), this.DeviceIndex = e, this.Endpoint = t, this.Id = n;
  }
}
Ye.Name = "RawUnsubscribeCmd";
class Xe extends J {
  constructor(e, t, n, i = D) {
    super(e, i), this.DeviceIndex = e, this.Endpoint = t, this.Data = n, this.Id = i;
  }
}
Xe.Name = "RawReading";
const Xt = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ActuatorType: ce,
  ButtplugDeviceMessage: J,
  ButtplugMessage: H,
  ButtplugSystemMessage: ue,
  DEFAULT_MESSAGE_ID: D,
  DeviceAdded: _e,
  DeviceInfo: De,
  DeviceList: Ne,
  DeviceRemoved: Te,
  Error: Q,
  ErrorClass: z,
  GenericDeviceMessageAttributes: qt,
  GenericMessageSubcommand: Se,
  LinearCmd: Ee,
  MAX_ID: Jt,
  MESSAGE_SPEC_VERSION: ge,
  MessageAttributes: Re,
  Ok: we,
  Ping: dt,
  RawDeviceMessageAttributes: Ht,
  RawReadCmd: Je,
  RawReading: Xe,
  RawSubscribeCmd: He,
  RawUnsubscribeCmd: Ye,
  RawWriteCmd: qe,
  RequestDeviceList: Pe,
  RequestServerInfo: $e,
  RotateCmd: Ae,
  RotateSubcommand: ht,
  SYSTEM_MESSAGE_ID: X,
  ScalarCmd: me,
  ScalarSubcommand: xe,
  ScanningFinished: Be,
  SensorDeviceMessageAttributes: Yt,
  SensorReadCmd: Ge,
  SensorReading: ze,
  SensorType: ee,
  ServerInfo: Fe,
  StartScanning: ke,
  StopAllDevices: We,
  StopDeviceCmd: Ue,
  StopScanning: je,
  VectorSubcommand: gt
}, Symbol.toStringTag, { value: "Module" }));
/*!
 * Buttplug JS Source Code File - Visit https://buttplug.io for more info about
 * the project. Licensed under the BSD 3-Clause license. See LICENSE file in the
 * project root for full license information.
 *
 * @copyright Copyright (c) Nonpolynomial Labs LLC. All rights reserved.
 */
class U extends Error {
  constructor(e, t, n = X, i) {
    super(e), this.errorClass = z.ERROR_UNKNOWN, this.errorClass = t, this.innerError = i, this.messageId = n;
  }
  get ErrorClass() {
    return this.errorClass;
  }
  get InnerError() {
    return this.innerError;
  }
  get Id() {
    return this.messageId;
  }
  get ErrorMessage() {
    return new Q(this.message, this.ErrorClass, this.Id);
  }
  static LogAndError(e, t, n, i = X) {
    return t.Error(n), new e(n, i);
  }
  static FromError(e) {
    switch (e.ErrorCode) {
      case z.ERROR_DEVICE:
        return new P(e.ErrorMessage, e.Id);
      case z.ERROR_INIT:
        return new Oe(e.ErrorMessage, e.Id);
      case z.ERROR_UNKNOWN:
        return new Qt(e.ErrorMessage, e.Id);
      case z.ERROR_PING:
        return new Zt(e.ErrorMessage, e.Id);
      case z.ERROR_MSG:
        return new de(e.ErrorMessage, e.Id);
      default:
        throw new Error(`Message type ${e.ErrorCode} not handled`);
    }
  }
}
class Oe extends U {
  constructor(e, t = X) {
    super(e, z.ERROR_INIT, t);
  }
}
class P extends U {
  constructor(e, t = X) {
    super(e, z.ERROR_DEVICE, t);
  }
}
class de extends U {
  constructor(e, t = X) {
    super(e, z.ERROR_MSG, t);
  }
}
class Zt extends U {
  constructor(e, t = X) {
    super(e, z.ERROR_PING, t);
  }
}
class Qt extends U {
  constructor(e, t = X) {
    super(e, z.ERROR_UNKNOWN, t);
  }
}
function vt(r) {
  for (const e of Object.values(Xt))
    if (typeof e == "function" && "Name" in e && e.Name === r)
      return e;
  return null;
}
function ne(r) {
  return vt(Object.getPrototypeOf(r).constructor.Name);
}
function ot(r) {
  const e = JSON.parse(r), t = [];
  for (const n of Array.from(e)) {
    const i = Object.getOwnPropertyNames(n)[0], u = vt(i);
    if (u) {
      const a = Wt(
        u,
        n[i]
      );
      a.update(), t.push(a);
    }
  }
  return t;
}
class ye extends ve {
  /**
   * @param _index Index of the device, as created by the device manager.
   * @param _name Name of the device.
   * @param allowedMsgs Buttplug messages the device can receive.
   */
  constructor(e, t) {
    super(), this._deviceInfo = e, this._sendClosure = t, this.allowedMsgs = /* @__PURE__ */ new Map(), e.DeviceMessages.update();
  }
  /**
   * Return the name of the device.
   */
  get name() {
    return this._deviceInfo.DeviceName;
  }
  /**
   * Return the user set name of the device.
   */
  get displayName() {
    return this._deviceInfo.DeviceDisplayName;
  }
  /**
   * Return the index of the device.
   */
  get index() {
    return this._deviceInfo.DeviceIndex;
  }
  /**
   * Return the index of the device.
   */
  get messageTimingGap() {
    return this._deviceInfo.DeviceMessageTimingGap;
  }
  /**
   * Return a list of message types the device accepts.
   */
  get messageAttributes() {
    return this._deviceInfo.DeviceMessages;
  }
  static fromMsg(e, t) {
    return new ye(e, t);
  }
  async send(e) {
    return await this._sendClosure(this, e);
  }
  async sendExpectOk(e) {
    const t = await this.send(e);
    switch (ne(t)) {
      case we:
        return;
      case Q:
        throw U.FromError(t);
      default:
        throw new de(
          `Message type ${t.constructor} not handled by SendMsgExpectOk`
        );
    }
  }
  async scalar(e) {
    Array.isArray(e) ? await this.sendExpectOk(new me(e, this.index)) : await this.sendExpectOk(new me([e], this.index));
  }
  async scalarCommandBuilder(e, t) {
    var u;
    const n = (u = this.messageAttributes.ScalarCmd) == null ? void 0 : u.filter(
      (a) => a.ActuatorType === t
    );
    if (!n || n.length === 0)
      throw new P(
        `Device ${this.name} has no ${t} capabilities`
      );
    const i = [];
    if (typeof e == "number")
      n.forEach(
        (a) => i.push(new xe(a.Index, e, t))
      );
    else if (Array.isArray(e)) {
      if (e.length > n.length)
        throw new P(
          `${e.length} commands send to a device with ${n.length} vibrators`
        );
      n.forEach((a, f) => {
        i.push(new xe(a.Index, e[f], t));
      });
    } else
      throw new P(
        `${t} can only take numbers or arrays of numbers.`
      );
    await this.scalar(i);
  }
  get vibrateAttributes() {
    var e;
    return ((e = this.messageAttributes.ScalarCmd) == null ? void 0 : e.filter(
      (t) => t.ActuatorType === ce.Vibrate
    )) ?? [];
  }
  async vibrate(e) {
    await this.scalarCommandBuilder(e, ce.Vibrate);
  }
  get oscillateAttributes() {
    var e;
    return ((e = this.messageAttributes.ScalarCmd) == null ? void 0 : e.filter(
      (t) => t.ActuatorType === ce.Oscillate
    )) ?? [];
  }
  async oscillate(e) {
    await this.scalarCommandBuilder(e, ce.Oscillate);
  }
  get rotateAttributes() {
    return this.messageAttributes.RotateCmd ?? [];
  }
  async rotate(e, t) {
    const n = this.messageAttributes.RotateCmd;
    if (!n || n.length === 0)
      throw new P(
        `Device ${this.name} has no Rotate capabilities`
      );
    let i;
    if (typeof e == "number")
      i = Ae.Create(
        this.index,
        new Array(n.length).fill([e, t])
      );
    else if (Array.isArray(e))
      i = Ae.Create(this.index, e);
    else
      throw new P(
        "SendRotateCmd can only take a number and boolean, or an array of number/boolean tuples"
      );
    await this.sendExpectOk(i);
  }
  get linearAttributes() {
    return this.messageAttributes.LinearCmd ?? [];
  }
  async linear(e, t) {
    const n = this.messageAttributes.LinearCmd;
    if (!n || n.length === 0)
      throw new P(
        `Device ${this.name} has no Linear capabilities`
      );
    let i;
    if (typeof e == "number")
      i = Ee.Create(
        this.index,
        new Array(n.length).fill([e, t])
      );
    else if (Array.isArray(e))
      i = Ee.Create(this.index, e);
    else
      throw new P(
        "SendLinearCmd can only take a number and number, or an array of number/number tuples"
      );
    await this.sendExpectOk(i);
  }
  async sensorRead(e, t) {
    const n = await this.send(
      new Ge(this.index, e, t)
    );
    switch (ne(n)) {
      case ze:
        return n.Data;
      case Q:
        throw U.FromError(n);
      default:
        throw new de(
          `Message type ${n.constructor} not handled by sensorRead`
        );
    }
  }
  get hasBattery() {
    var t;
    const e = (t = this.messageAttributes.SensorReadCmd) == null ? void 0 : t.filter(
      (n) => n.SensorType === ee.Battery
    );
    return e !== void 0 && e.length > 0;
  }
  async battery() {
    var n;
    if (!this.hasBattery)
      throw new P(
        `Device ${this.name} has no Battery capabilities`
      );
    const e = (n = this.messageAttributes.SensorReadCmd) == null ? void 0 : n.filter(
      (i) => i.SensorType === ee.Battery
    );
    return (await this.sensorRead(
      e[0].Index,
      ee.Battery
    ))[0] / 100;
  }
  get hasRssi() {
    var t;
    const e = (t = this.messageAttributes.SensorReadCmd) == null ? void 0 : t.filter(
      (n) => n.SensorType === ee.RSSI
    );
    return e !== void 0 && e.length === 0;
  }
  async rssi() {
    var n;
    if (!this.hasRssi)
      throw new P(
        `Device ${this.name} has no RSSI capabilities`
      );
    const e = (n = this.messageAttributes.SensorReadCmd) == null ? void 0 : n.filter(
      (i) => i.SensorType === ee.RSSI
    );
    return (await this.sensorRead(
      e[0].Index,
      ee.RSSI
    ))[0];
  }
  async rawRead(e, t, n) {
    if (!this.messageAttributes.RawReadCmd)
      throw new P(
        `Device ${this.name} has no raw read capabilities`
      );
    if (this.messageAttributes.RawReadCmd.Endpoints.indexOf(e) === -1)
      throw new P(
        `Device ${this.name} has no raw readable endpoint ${e}`
      );
    const i = await this.send(
      new Je(this.index, e, t, n)
    );
    switch (ne(i)) {
      case Xe:
        return new Uint8Array(i.Data);
      case Q:
        throw U.FromError(i);
      default:
        throw new de(
          `Message type ${i.constructor} not handled by rawRead`
        );
    }
  }
  async rawWrite(e, t, n) {
    if (!this.messageAttributes.RawWriteCmd)
      throw new P(
        `Device ${this.name} has no raw write capabilities`
      );
    if (this.messageAttributes.RawWriteCmd.Endpoints.indexOf(e) === -1)
      throw new P(
        `Device ${this.name} has no raw writable endpoint ${e}`
      );
    await this.sendExpectOk(
      new qe(this.index, e, t, n)
    );
  }
  async rawSubscribe(e) {
    if (!this.messageAttributes.RawSubscribeCmd)
      throw new P(
        `Device ${this.name} has no raw subscribe capabilities`
      );
    if (this.messageAttributes.RawSubscribeCmd.Endpoints.indexOf(e) === -1)
      throw new P(
        `Device ${this.name} has no raw subscribable endpoint ${e}`
      );
    await this.sendExpectOk(new He(this.index, e));
  }
  async rawUnsubscribe(e) {
    if (!this.messageAttributes.RawSubscribeCmd)
      throw new P(
        `Device ${this.name} has no raw unsubscribe capabilities`
      );
    if (this.messageAttributes.RawSubscribeCmd.Endpoints.indexOf(e) === -1)
      throw new P(
        `Device ${this.name} has no raw unsubscribable endpoint ${e}`
      );
    await this.sendExpectOk(
      new Ye(this.index, e)
    );
  }
  async stop() {
    await this.sendExpectOk(new Ue(this.index));
  }
  emitDisconnected() {
    this.emit("deviceremoved");
  }
}
/*!
 * Buttplug JS Source Code File - Visit https://buttplug.io for more info about
 * the project. Licensed under the BSD 3-Clause license. See LICENSE file in the
 * project root for full license information.
 *
 * @copyright Copyright (c) Nonpolynomial Labs LLC. All rights reserved.
 */
class Kt {
  constructor(e) {
    this._useCounter = e, this._counter = 1, this._waitingMsgs = /* @__PURE__ */ new Map();
  }
  // One of the places we should actually return a promise, as we need to store
  // them while waiting for them to return across the line.
  // tslint:disable:promise-function-async
  PrepareOutgoingMessage(e) {
    this._useCounter && (e.Id = this._counter, this._counter += 1);
    let t, n;
    const i = new Promise(
      (u, a) => {
        t = u, n = a;
      }
    );
    return this._waitingMsgs.set(e.Id, [t, n]), i;
  }
  ParseIncomingMessages(e) {
    const t = [];
    for (const n of e)
      if (n.Id !== X && this._waitingMsgs.has(n.Id)) {
        const [i, u] = this._waitingMsgs.get(n.Id);
        if (n.Type === Q) {
          u(U.FromError(n));
          continue;
        }
        i(n);
        continue;
      } else
        t.push(n);
    return t;
  }
}
/*!
 * Buttplug JS Source Code File - Visit https://buttplug.io for more info about
 * the project. Licensed under the BSD 3-Clause license. See LICENSE file in the
 * project root for full license information.
 *
 * @copyright Copyright (c) Nonpolynomial Labs LLC. All rights reserved.
 */
class Vt extends U {
  constructor(e) {
    super(e, z.ERROR_UNKNOWN);
  }
}
class sn extends ve {
  constructor(e = "Generic Buttplug Client") {
    super(), this._pingTimer = null, this._connector = null, this._devices = /* @__PURE__ */ new Map(), this._logger = Pt.Logger, this._isScanning = !1, this._sorter = new Kt(!0), this.connect = async (t) => {
      this._logger.Info(
        `ButtplugClient: Connecting using ${t.constructor.name}`
      ), await t.connect(), this._connector = t, this._connector.addListener("message", this.parseMessages), this._connector.addListener("disconnect", this.disconnectHandler), await this.initializeConnection();
    }, this.disconnect = async () => {
      this._logger.Debug("ButtplugClient: Disconnect called"), this.checkConnector(), await this.shutdownConnection(), await this._connector.disconnect();
    }, this.startScanning = async () => {
      this._logger.Debug("ButtplugClient: StartScanning called"), this._isScanning = !0, await this.sendMsgExpectOk(new ke());
    }, this.stopScanning = async () => {
      this._logger.Debug("ButtplugClient: StopScanning called"), this._isScanning = !1, await this.sendMsgExpectOk(new je());
    }, this.stopAllDevices = async () => {
      this._logger.Debug("ButtplugClient: StopAllDevices"), await this.sendMsgExpectOk(new We());
    }, this.disconnectHandler = () => {
      this._logger.Info("ButtplugClient: Disconnect event receieved."), this.emit("disconnect");
    }, this.parseMessages = (t) => {
      const n = this._sorter.ParseIncomingMessages(t);
      for (const i of n)
        switch (ne(i)) {
          case _e: {
            const u = i, a = ye.fromMsg(
              u,
              this.sendDeviceMessageClosure
            );
            this._devices.set(u.DeviceIndex, a), this.emit("deviceadded", a);
            break;
          }
          case Te: {
            const u = i;
            if (this._devices.has(u.DeviceIndex)) {
              const a = this._devices.get(u.DeviceIndex);
              a == null || a.emitDisconnected(), this._devices.delete(u.DeviceIndex), this.emit("deviceremoved", a);
            }
            break;
          }
          case Be:
            this._isScanning = !1, this.emit("scanningfinished", i);
            break;
        }
    }, this.initializeConnection = async () => {
      this.checkConnector();
      const t = await this.sendMessage(
        new $e(
          this._clientName,
          ge
        )
      );
      switch (ne(t)) {
        case Fe: {
          const n = t;
          if (this._logger.Info(
            `ButtplugClient: Connected to Server ${n.ServerName}`
          ), n.MaxPingTime, n.MessageVersion < ge)
            throw await this._connector.disconnect(), U.LogAndError(
              Oe,
              this._logger,
              `Server protocol version ${n.MessageVersion} is older than client protocol version ${ge}. Please update server.`
            );
          return await this.requestDeviceList(), !0;
        }
        case Q: {
          await this._connector.disconnect();
          const n = t;
          throw U.LogAndError(
            Oe,
            this._logger,
            `Cannot connect to server. ${n.ErrorMessage}`
          );
        }
      }
      return !1;
    }, this.requestDeviceList = async () => {
      this.checkConnector(), this._logger.Debug("ButtplugClient: ReceiveDeviceList called"), (await this.sendMessage(
        new Pe()
      )).Devices.forEach((n) => {
        if (this._devices.has(n.DeviceIndex))
          this._logger.Debug(`ButtplugClient: Device already added: ${n}`);
        else {
          const i = ye.fromMsg(
            n,
            this.sendDeviceMessageClosure
          );
          this._logger.Debug(`ButtplugClient: Adding Device: ${i}`), this._devices.set(n.DeviceIndex, i), this.emit("deviceadded", i);
        }
      });
    }, this.shutdownConnection = async () => {
      await this.stopAllDevices(), this._pingTimer !== null && (clearInterval(this._pingTimer), this._pingTimer = null);
    }, this.sendMsgExpectOk = async (t) => {
      const n = await this.sendMessage(t);
      switch (ne(n)) {
        case we:
          return;
        case Q:
          throw U.FromError(n);
        default:
          throw U.LogAndError(
            de,
            this._logger,
            `Message type ${ne(n).constructor} not handled by SendMsgExpectOk`
          );
      }
    }, this.sendDeviceMessageClosure = async (t, n) => await this.sendDeviceMessage(t, n), this._clientName = e, this._logger.Debug(`ButtplugClient: Client ${e} created.`);
  }
  get connected() {
    return this._connector !== null && this._connector.Connected;
  }
  get devices() {
    this.checkConnector();
    const e = [];
    return this._devices.forEach((t) => {
      e.push(t);
    }), e;
  }
  get isScanning() {
    return this._isScanning;
  }
  async sendDeviceMessage(e, t) {
    if (this.checkConnector(), this._devices.get(e.index) === void 0)
      throw U.LogAndError(
        P,
        this._logger,
        `Device ${e.index} not available.`
      );
    return t.DeviceIndex = e.index, await this.sendMessage(t);
  }
  async sendMessage(e) {
    this.checkConnector();
    const t = this._sorter.PrepareOutgoingMessage(e);
    return await this._connector.send(e), await t;
  }
  checkConnector() {
    if (!this.connected)
      throw new Vt(
        "ButtplugClient not connected"
      );
  }
}
class en extends ve {
  constructor(e) {
    super(), this._url = e, this._websocketConstructor = null, this.connect = async () => {
      const t = new (this._websocketConstructor ?? WebSocket)(this._url);
      let n, i;
      const u = new Promise((f, l) => {
        n = f, i = l;
      }), a = () => i();
      return t.addEventListener("open", async () => {
        this._ws = t;
        try {
          await this.initialize(), this._ws.addEventListener("message", (f) => {
            this.parseIncomingMessage(f);
          }), this._ws.removeEventListener("close", a), this._ws.addEventListener("close", this.disconnect), n();
        } catch (f) {
          console.log(f), i();
        }
      }), t.addEventListener("close", a), u;
    }, this.disconnect = async () => {
      this.Connected && (this._ws.close(), this._ws = void 0, this.emit("disconnect"));
    }, this.initialize = async () => Promise.resolve();
  }
  get Connected() {
    return this._ws !== void 0;
  }
  sendMessage(e) {
    if (!this.Connected)
      throw new Error("ButtplugBrowserWebsocketConnector not connected");
    this._ws.send("[" + e.toJSON() + "]");
  }
  parseIncomingMessage(e) {
    if (typeof e.data == "string") {
      const t = ot(e.data);
      this.emit("message", t);
    } else
      e.data instanceof Blob;
  }
  onReaderLoad(e) {
    const t = ot(e.target.result);
    this.emit("message", t);
  }
}
class tn extends en {
  constructor() {
    super(...arguments), this.send = (e) => {
      if (!this.Connected)
        throw new Error("ButtplugClient not connected");
      this.sendMessage(e);
    };
  }
}
var nn = function() {
  throw new Error(
    "ws does not work in the browser. Browser clients must use the native WebSocket object"
  );
};
class on extends tn {
  constructor() {
    super(...arguments), this._websocketConstructor = nn.WebSocket;
  }
}
export {
  ce as ActuatorType,
  tn as ButtplugBrowserWebsocketClientConnector,
  sn as ButtplugClient,
  Vt as ButtplugClientConnectorException,
  ye as ButtplugClientDevice,
  P as ButtplugDeviceError,
  J as ButtplugDeviceMessage,
  U as ButtplugError,
  Oe as ButtplugInitError,
  ct as ButtplugLogLevel,
  Pt as ButtplugLogger,
  H as ButtplugMessage,
  de as ButtplugMessageError,
  Kt as ButtplugMessageSorter,
  on as ButtplugNodeWebsocketClientConnector,
  Zt as ButtplugPingError,
  ue as ButtplugSystemMessage,
  Qt as ButtplugUnknownError,
  D as DEFAULT_MESSAGE_ID,
  _e as DeviceAdded,
  De as DeviceInfo,
  Ne as DeviceList,
  Te as DeviceRemoved,
  Q as Error,
  z as ErrorClass,
  qt as GenericDeviceMessageAttributes,
  Se as GenericMessageSubcommand,
  Ee as LinearCmd,
  Tt as LogMessage,
  Jt as MAX_ID,
  ge as MESSAGE_SPEC_VERSION,
  Re as MessageAttributes,
  we as Ok,
  dt as Ping,
  Ht as RawDeviceMessageAttributes,
  Je as RawReadCmd,
  Xe as RawReading,
  He as RawSubscribeCmd,
  Ye as RawUnsubscribeCmd,
  qe as RawWriteCmd,
  Pe as RequestDeviceList,
  $e as RequestServerInfo,
  Ae as RotateCmd,
  ht as RotateSubcommand,
  X as SYSTEM_MESSAGE_ID,
  me as ScalarCmd,
  xe as ScalarSubcommand,
  Be as ScanningFinished,
  Yt as SensorDeviceMessageAttributes,
  Ge as SensorReadCmd,
  ze as SensorReading,
  ee as SensorType,
  Fe as ServerInfo,
  ke as StartScanning,
  We as StopAllDevices,
  Ue as StopDeviceCmd,
  je as StopScanning,
  gt as VectorSubcommand,
  ot as fromJSON,
  ne as getMessageClassFromMessage
};
