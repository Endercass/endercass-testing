async function proxiedURL(url) {
    await window.navigator.serviceWorker.register("/sw.js");
    return __uv$config.prefix + __uv$config.decodeUrl(url);
}

async function auth(spaceFetch, passwordCallback) {
    const res = await (await spaceFetch("/space")).json();
    console.log(res);

    return await fetch(
        await proxiedURL("https://deta.space/api/v0/auth/login"),
        {
            method: "POST",
            headers: {
                "content-type": "application/json",
            },
            body: JSON.stringify({
                username: res.name,
                password: passwordCallback(res.name),
            }),
            redirect: "manual",
        },
    );
}

bare.createBareClient(anura.settings.get("bare-url"))
    .then(async (client) => {
        if (!anura.settings.get("DETASPACETOKEN")) {
            anura.settings.set(
                "DETASPACETOKEN",
                prompt("Deta Space API Token"),
            );
        }
        const spaceFetch = detaBareClient.fetchFn(
            anura.settings.get("DETASPACETOKEN"),
            client,
        );

        let authButton = document.createElement("button");
        authButton.className = "authButton";
        authButton.innerText = "Authenticate";
        authButton.addEventListener("click", async () => {
            await auth(spaceFetch, (username) => {
                return prompt(`Password for ${username}:`);
            });
        });

        let appsDiv = document.createElement("div");
        appsDiv.className = "appsDiv";
        document.body.appendChild(appsDiv);

        appsDiv.appendChild(authButton);

        console.log(window.parent);

        spaceFetch("/instances")
            .then((res) => res.json())
            .then(async (payload) => {
                console.log(payload);
                payload.instances.map(async (val, i, arr) => {
                    let appDiv = document.createElement("div");
                    appDiv.className = "appDiv";

                    let appInnerDiv = document.createElement("div");
                    appInnerDiv.className = "appInnerDiv";
                    appDiv.appendChild(appInnerDiv);

                    let appIconContainer = document.createElement("div");
                    appIconContainer.className = "appIconContainer";
                    appIconContainer.addEventListener("click", () => {
                        launchSpaceApp(val);
                    });

                    if (val.release.icon_url != "") {
                        let appIcon = document.createElement("img");
                        appIcon.className = "appIcon";

                        appIcon.src = URL.createObjectURL(
                            await (
                                await client.fetch(val.release.icon_url)
                            ).blob(),
                        );

                        appIcon.setAttribute("draggable", false);

                        appIconContainer.appendChild(appIcon);
                    } else {
                        let appIcon = document.createElement("div");
                        appIcon.className = "appIconMissing";
                        appIconContainer.appendChild(appIcon);
                    }

                    appInnerDiv.appendChild(appIconContainer);

                    let appName = document.createElement("span");
                    appName.innerText = val.release.app_name;
                    appName.className = "appTitle";
                    appInnerDiv.appendChild(appName);

                    appsDiv.appendChild(appDiv);
                });
            });
    })
    .catch((err) => {
        console.error(err);
    });

async function launchSpaceApp(instance) {
    let win = anura.wm.create(anura.apps["space.deta.anura"], {
        title: `${instance.release.app_name} | Deta Space`,
    });
    const frame = document.createElement("iframe");
    frame.setAttribute(
        "style",
        "top:0; left:0; bottom:0; right:0; width:100%; height:100%; border: none; margin: 0; padding: 0; background-color: #202124;",
    );

    frame.src = await proxiedURL(instance.url);
    win.content.appendChild(frame);
}
